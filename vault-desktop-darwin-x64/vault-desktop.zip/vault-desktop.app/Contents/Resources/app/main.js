require('menubar')({
  icon: 'assets/dots.png',
  height: 240,
  width: 320,
})